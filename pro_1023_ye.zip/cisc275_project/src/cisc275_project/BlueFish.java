package cisc275_project;

public class BlueFish extends Animal {
	public BlueFish(int xPos, int yPos) {
		super("blue_fish", xPos, yPos, 4, 1, false);
	}	
}
